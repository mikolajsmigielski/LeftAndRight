﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BackToMenu : MonoBehaviour
{
    float TimeToWait = 2;//variable for time to wait
    
    // Update is called once per frame
    void Update() 
    {
        TimeToWait -= Time.deltaTime;//Decrease the time to wait
        if (Input.anyKey == true && TimeToWait <= 0)//if any key was active, and time to wait is below or equals, then reset time to wait and load main menu
        {
            TimeToWait = 2;
            SceneManager.LoadScene(0);
            
        }
        
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HowToPlayScript : MonoBehaviour
{
    

    // Update is called once per frame
    void Update()
    {
        if (Input.anyKeyDown == true)////if this function is active, load main menu scene
        {
            SceneManager.LoadScene(0);
        }
    }
}

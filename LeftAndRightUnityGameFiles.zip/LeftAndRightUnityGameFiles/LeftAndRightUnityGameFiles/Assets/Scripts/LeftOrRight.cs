﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LeftOrRight : MonoBehaviour
{
    
    public SpriteRenderer SRSquare;//Public variable to get access  for SpriteRenderer for 
    int RandColor;//variable to the drawn color
    public float Points = 0f;//variable of points
    bool PointsCollected = false;//a flag indicating whether or not points have been collected
    public int Life = 3;//variable of life
    bool LifeTaken = false;//a flag indicating whether or not life have been lost
    float TimeLeft = 2f;//Time to answer
    public AudioSource ASWrong;// public variable to sound effect for wrong answer
    public AudioSource ASCorrect;// public variable to sound effect for correct answer
    // Start is called before the first frame update
    void Start()
    {
        SRSquare.color = new Color(255, 255, 255, 255);//Set the first color to white

    }

    // Update is called once per frame
    void Update()
    {
        
        if (TimeLeft > 0)
        {
            TimeLeft -= Time.deltaTime;//Decrease the time to answer
        }
        else
        {
            TimeLeft = 0;//Set TimeLeft to 0
        }
        
        //Color change
        if (Input.GetButtonUp("Horizontal") == true)//if "Horizontal" buttom up
        {
            RandColor = Random.Range(0, 2);//chose number between 0 and 1
            if (RandColor == 0)//if chosen number is 0, set color to white
            {
                SRSquare.color = new Color(255, 255, 255, 255);
               
            }
            if (RandColor == 1)//if chosen number is 1, set color to red
            {
                SRSquare.color = new Color(255, 0, 0, 255);
                
            }
            PointsCollected = false;// set a flag indicating that you have collected points for the false
            LifeTaken = false;// set a flag indicating that you have lost life for the false
        }
        if (Input.GetAxisRaw("Horizontal") == -1 && RandColor == 0 && PointsCollected == false)// if chosen "Horizontal" button is negative when color ist set to white and Points was not collected, then
        {
            Points+=TimeLeft;// Add the remaining time to the points
            TimeLeft = 2f;//Set time again to 2 seconds
            PointsCollected = true;// set a flag indicating that you have collected points for the truth
            ASCorrect.Play();//Play sound
        }
        else if (Input.GetAxisRaw("Horizontal") == 1 && RandColor == 1 && PointsCollected == false)// if chosen "Horizontal" button is positive when color ist set to red and Points was not collected, then
        {
            Points += TimeLeft;// Add the remaining time to the points
            TimeLeft = 2f;//Set time again to 2 seconds
            PointsCollected = true;// set a flag indicating that you have collected points for the truth
            ASCorrect.Play();//Play sound
        }
        else if((Input.GetAxisRaw("Horizontal") == -1 && RandColor == 1 && PointsCollected == false && LifeTaken == false) ||(Input.GetAxisRaw("Horizontal") == 1 && RandColor == 0 && PointsCollected == false && LifeTaken == false))//if the selected button does not match the drawn color, then
        {
            Life--;//reduce life by 1
            LifeTaken = true;//set a flag indicating that you have lost life for the truth
            ASWrong.Play();//Play sound
        }
        if (Life <= 0)// if lost all life
        {
            PlayerPrefs.SetFloat("Score", Points);// Assign collected points
            if (PlayerPrefs.GetFloat("BestScore") < Points)//if the best score is less than the points collected, then assign points as the best score
            {
                PlayerPrefs.SetFloat("BestScore", Points);
            }
            SceneManager.LoadScene(2);//load "GameOver" scene
        }

        
    }
    

}

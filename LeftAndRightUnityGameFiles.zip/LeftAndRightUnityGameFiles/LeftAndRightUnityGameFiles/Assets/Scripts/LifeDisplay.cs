﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LifeDisplay : MonoBehaviour
{
    public LeftOrRight Player;// public variable to get access for "LeftOrRight" script
    public Text PlayerLife;// public variable to get access for Text

    // Update is called once per frame
    void Update()
    {
        PlayerLife.text = Player.Life.ToString();//display on screen numbers of life
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameoverScoreDisplay : MonoBehaviour
{
    public Text PlayerScore;// public variable to get access for Text
    public Text PlayerBestScore;// public variable to get access for Text
    
    private void Start()
    {
        PlayerScore.text = PlayerPrefs.GetFloat("Score").ToString("0.0");//display on screen player score
        if (PlayerPrefs.GetFloat("BestScore") == PlayerPrefs.GetFloat("Score"))// Score is equal to best score, display on screen text "NEW BEST SCORE!!!"
        {
            PlayerBestScore.text = "NEW BEST SCORE!!!";
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public LeftOrRight Player;// public variable to get access for "LeftOrRight" script
    public Text PlayerScore;// public variable to get access for Text

    // Update is called once per frame
    void Update()
    {
        PlayerScore.text = Player.Points.ToString("0.0");//display on screen numbers of points
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenuManager : MonoBehaviour
{
    public AudioSource AS;//public variable to sound effect 
    public Text BestScore;//public variable to text for displaying BestScore 

    private void Start()
    {
        BestScore.text = PlayerPrefs.GetFloat("BestScore").ToString("0.0");//display BestScore on screen
    }
    private void Update()
    {
        if (Input.anyKeyDown == true)//If any key is down, then play sound
        {
            AS.Play();
        }
    }
    public void PlayGame()//if this function is active, load main scene to play a game
    {
        SceneManager.LoadScene(1);
    }
    public void QuitGame()//if this function is active, exit a game
    {
        Application.Quit();
    }
}
